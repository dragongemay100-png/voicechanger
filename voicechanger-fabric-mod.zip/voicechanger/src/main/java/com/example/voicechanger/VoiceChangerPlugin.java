package com.example.voicechanger;

import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.ClientSoundEvent;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import net.minecraft.client.MinecraftClient;

/** Plugin بتاع Simple Voice Chat جوه المود: بيغير صوت المايك قبل الإرسال. */
public class VoiceChangerPlugin implements VoicechatPlugin {

    private final VoiceProcessor processor = new VoiceProcessor();

    @Override
    public String getPluginId() {
        return "voicechanger";
    }

    @Override
    public void initialize(VoicechatApi api) {
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(ClientSoundEvent.class, this::onMic);
    }

    private void onMic(ClientSoundEvent event) {
        Preset p = VoiceChangerClient.current;
        if (p == Preset.NORMAL) return;

        // يشتغل بس على سيرفر حقيقي، مش سينجل بلاير
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getCurrentServerEntry() == null || mc.isInSingleplayer()) return;

        short[] audio = event.getRawAudio();
        if (audio == null) return;

        processor.process(audio, p);
        event.setRawAudio(audio);
    }
}
