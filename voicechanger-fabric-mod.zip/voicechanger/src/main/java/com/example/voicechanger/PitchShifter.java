package com.example.voicechanger;

/** Pitch shifter بسيط: delay-line بقراءتين متداخلتين (crossfade). */
public class PitchShifter {
    private static final int SIZE = 4096;
    private static final int MASK = SIZE - 1;
    private static final float WIN = 1024f;

    private final float[] buf = new float[SIZE];
    private int w = 0;
    private float phase = 0f;
    private float ratio = 1f;

    public void setRatio(float r) {
        this.ratio = Math.max(0.5f, Math.min(2.0f, r));
    }

    public float process(float in) {
        buf[w] = in;
        w = (w + 1) & MASK;

        phase += (1f - ratio) / WIN;
        phase -= (float) Math.floor(phase);

        float p2 = phase + 0.5f;
        p2 -= (float) Math.floor(p2);

        return read(phase) * win(phase) + read(p2) * win(p2);
    }

    private float win(float p) {
        double s = Math.sin(Math.PI * p);
        return (float) (s * s);
    }

    private float read(float p) {
        float delay = p * WIN + 1f;
        float pos = w - delay;
        while (pos < 0) pos += SIZE;
        int i0 = ((int) pos) & MASK;
        int i1 = (i0 + 1) & MASK;
        float frac = pos - (float) Math.floor(pos);
        return buf[i0] * (1f - frac) + buf[i1] * frac;
    }
}
