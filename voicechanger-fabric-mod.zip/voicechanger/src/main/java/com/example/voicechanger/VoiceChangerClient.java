package com.example.voicechanger;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;

public class VoiceChangerClient implements ClientModInitializer {

    public static volatile Preset current = Preset.NORMAL;

    private static KeyBinding nextKey;
    private static KeyBinding prevKey;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("voicechanger", "main"));

        nextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.voicechanger.next", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_BRACKET, cat));
        prevKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.voicechanger.prev", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET, cat));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.voicechanger.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_BACKSLASH, cat));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (nextKey.wasPressed()) { current = current.next(); show(client); }
            while (prevKey.wasPressed()) { current = current.prev(); show(client); }
            while (toggleKey.wasPressed()) {
                current = (current == Preset.NORMAL) ? Preset.DEEP : Preset.NORMAL;
                show(client);
            }
        });

        // /vc deep  |  /vc high  |  /vc robot ...
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("vc")
                        .then(ClientCommandManager.argument("preset", StringArgumentType.word())
                                .suggests((ctx, b) -> CommandSource.suggestMatching(
                                        Arrays.stream(Preset.values()).map(Preset::id).toList(), b))
                                .executes(ctx -> {
                                    Preset p = Preset.fromName(StringArgumentType.getString(ctx, "preset"));
                                    if (p == null) {
                                        ctx.getSource().sendFeedback(Text.literal("Unknown voice. Use: "
                                                + String.join(", ", Arrays.stream(Preset.values()).map(Preset::id).toList())));
                                        return 0;
                                    }
                                    current = p;
                                    ctx.getSource().sendFeedback(Text.literal("Voice: " + p.label));
                                    return 1;
                                }))));
    }

    private static void show(MinecraftClient client) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal("Voice: " + current.label), true);
        }
    }
}
