package com.example.voicechanger;

public enum Preset {
    NORMAL("Normal", 1.0f, 0f, false, false, false),
    DEEP("Deep voice", 0.75f, 0f, false, false, false),
    VERY_DEEP("Very deep voice", 0.60f, 0f, false, false, false),
    HIGH("High voice", 1.35f, 0f, false, false, false),
    CHIPMUNK("Chipmunk", 1.75f, 0f, false, false, false),
    ROBOT("Robot", 1.0f, 55f, false, false, false),
    ALIEN("Alien", 1.30f, 30f, false, false, false),
    MONSTER("Monster", 0.55f, 0f, true, false, false),
    ECHO("Echo", 1.0f, 0f, false, true, false),
    TELEPHONE("Telephone", 1.0f, 0f, false, false, true);

    public final String label;
    public final float pitch;      // 1.0 = no change, <1 deeper, >1 higher
    public final float ringHz;     // ring modulation (robot effect), 0 = off
    public final boolean distortion;
    public final boolean echo;
    public final boolean telephone;

    Preset(String label, float pitch, float ringHz, boolean distortion, boolean echo, boolean telephone) {
        this.label = label;
        this.pitch = pitch;
        this.ringHz = ringHz;
        this.distortion = distortion;
        this.echo = echo;
        this.telephone = telephone;
    }

    public String id() {
        return name().toLowerCase();
    }

    public static Preset fromName(String s) {
        for (Preset p : values()) {
            if (p.id().equalsIgnoreCase(s)) return p;
        }
        return null;
    }

    public Preset next() {
        Preset[] all = values();
        return all[(ordinal() + 1) % all.length];
    }

    public Preset prev() {
        Preset[] all = values();
        return all[(ordinal() + all.length - 1) % all.length];
    }
}
