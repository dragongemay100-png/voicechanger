package com.example.voicechanger;

/** بيطبق الـ preset على فريم صوت (48kHz mono, 16-bit). نسخة لكل لاعب. */
public class VoiceProcessor {
    private static final float SR = 48000f;
    private static final double TWO_PI = Math.PI * 2.0;

    private final PitchShifter pitch = new PitchShifter();
    private final float[] echoBuf = new float[(int) (SR * 0.28f)];
    private int echoPos = 0;
    private double ringPhase = 0;
    private float lp1 = 0, lp2 = 0;

    public void process(short[] a, Preset p) {
        pitch.setRatio(p.pitch);
        for (int i = 0; i < a.length; i++) {
            float x = a[i];

            if (p.pitch != 1.0f) x = pitch.process(x);

            if (p.ringHz > 0f) {
                x *= (float) Math.sin(ringPhase) * 1.4f;
                ringPhase += TWO_PI * p.ringHz / SR;
                if (ringPhase > TWO_PI) ringPhase -= TWO_PI;
            }

            if (p.distortion) {
                x = (float) Math.tanh(x / 8000.0) * 20000f;
            }

            if (p.telephone) {
                lp1 += 0.35f * (x - lp1);
                lp2 += 0.03f * (lp1 - lp2);
                x = (lp1 - lp2) * 1.3f;
            }

            if (p.echo) {
                float d = echoBuf[echoPos];
                float out = x + d * 0.45f;
                echoBuf[echoPos] = x + d * 0.35f;
                echoPos = (echoPos + 1) % echoBuf.length;
                x = out;
            }

            if (x > 32767f) x = 32767f;
            if (x < -32768f) x = -32768f;
            a[i] = (short) x;
        }
    }
}
